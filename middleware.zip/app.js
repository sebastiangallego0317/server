const express = require('express');
const bodyParser = require('body-parser');
const jwtSender = require('./routes/jwtSender'); // Ruta para enviar tokens JWT
const addProduct = require('./routes/addProduct'); // Ruta para agregar productos
const updateProd = require('./routes/updateProd'); // Ruta para actualizar productos
const deleteAProduct = require('./routes/deleteProduct'); // Ruta para eliminar productos
const comprarProducto = require('./routes/comprarProducto'); // Ruta para comprar productos
const getUserInfo = require('./routes/getUserInfo'); // Ruta para obtener información de usuario

const register = require('./routes/register'); // Ruta para registrar usuarios
const auth = require('./routes/auth'); // Ruta para autenticar usuarios
const products = require('./routes/products'); // Ruta para obtener lista de productos

const signingKey = require('./config/keys'); // Clave para firmar JWT
const cookieParser = require('cookie-parser'); // Middleware para manejar cookies

const app = express()
  .use(bodyParser.json()) // Middleware para parsear JSON en las solicitudes
  .use(cookieParser(signingKey.SIGNING_KEY_COOKIE)); // Middleware para manejar cookies con la clave

let port = 10101; // Puerto en el que se ejecutará el servidor Express

// Configuración de las rutas
app.use('/comprarProducto', comprarProducto); // Ruta para comprar productos
app.use('/getUserInfo', getUserInfo); // Ruta para obtener información de usuario
app.use('/register', register); // Ruta para registrar usuarios
app.use('/deleteAProduct', deleteAProduct); // Ruta para eliminar productos
app.use('/updateProd', updateProd); // Ruta para actualizar productos
app.use('/auth', auth); // Ruta para autenticar usuarios
app.use('/products', products); // Ruta para obtener lista de productos
app.use('/readToken', jwtSender); // Ruta para enviar tokens JWT
app.use('/addProduct', addProduct); // Ruta para agregar productos

// Inicia el servidor Express y escucha en el puerto especificado
app.listen(port, () => {
  console.log(`Express server listening on port ${port}`);
});
