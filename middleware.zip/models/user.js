class User {
  constructor(id, nombre, email, contrasena) {
    this.id = id;
    this.nombre = nombre;
    this.email = email;
    this.contrasena = contrasena;
  }
}

module.exports = User;